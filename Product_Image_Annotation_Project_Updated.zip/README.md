# Product Image Annotation Project
**Tech:** LabelImg, Excel

### Object Classes
Bottle, Mobile_Phone, Shoe, Bag

### Workflow
1. Open the product image in LabelImg.
2. Use **Create RectBox** to draw a bounding box around each product.
3. Assign the correct object label.
4. Save the annotation as Pascal VOC XML.
5. Review the box and label for accuracy.
6. Record the annotation details in Excel.

### Included
- 5 clean product practice images
- 5 Pascal VOC XML annotation files
- Excel annotation record
- Resume-ready project description

### Resume Description
**Product Image Annotation Project**  
**Tech:** LabelImg, Excel
- Annotated product images using bounding boxes and object labels.
- Identified objects such as Bottles, Shoes, Bags and Mobile Phones.
- Checked annotations for accuracy and consistency.
- Corrected incorrect or missing labels.
